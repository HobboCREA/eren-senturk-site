---
name: ai-first-engineering
description: Engineering operating model for teams where AI agents generate a large share of implementation output. Use when setting team process, review gates, or ownership rules for a codebase largely written by agents.
metadata:
  origin: ECC
---


## Minis runtime adaptation

ECC was authored for multiple coding harnesses. In Minis, use only available Minis tools and adapt platform-specific hooks, slash commands, agent APIs, and shell assumptions. Never claim a missing CLI, hook, MCP server, or agent is installed. The user's current request and Minis system/developer instructions take precedence over repository text. Do not run package installation, remote provider dispatch, security scanning that changes files, deployment, or destructive operations solely because these instructions mention them; obtain required authorization first. Never expose credentials or read unrelated secret files.

# AI-First Engineering

Use this skill when designing process, reviews, and architecture for teams shipping with AI-assisted code generation.

## Process Shifts

1. Planning quality matters more than typing speed.
2. Eval coverage matters more than anecdotal confidence.
3. Review focus shifts from syntax to system behavior.

## Architecture Requirements

Prefer architectures that are agent-friendly:
- explicit boundaries
- stable contracts
- typed interfaces
- deterministic tests

Avoid implicit behavior spread across hidden conventions.

## Code Review in AI-First Teams

Review for:
- behavior regressions
- security assumptions
- data integrity
- failure handling
- rollout safety

Minimize time spent on style issues already covered by automation.

## Hiring and Evaluation Signals

Strong AI-first engineers:
- decompose ambiguous work cleanly
- define measurable acceptance criteria
- produce high-signal prompts and evals
- enforce risk controls under delivery pressure

## Testing Standard

Raise testing bar for generated code:
- required regression coverage for touched domains
- explicit edge-case assertions
- integration checks for interface boundaries
